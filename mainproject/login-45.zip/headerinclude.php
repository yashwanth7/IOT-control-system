<!DOCTYPE html>
<html>
    <head>
    <title>
       vehicles page
    </title>
    <link rel="stylesheet" type="text/css" href="site.css">
    
    </head>
    <body>
    <div class="wrapper">
	<header>
		SMART TRAFFIC CONTROL SYSTEM
	</header>
        </div>
    </body>
</html>