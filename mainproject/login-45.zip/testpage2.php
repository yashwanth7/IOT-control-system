<!DOCTYPE html>
<html>
    <head>
    <title>
       vehicles page
    </title>
    <link rel="stylesheet" type="text/css" href="testpage2.css">
    
    </head>
    <body>
        <?php include 'headerinclude.php';?>
        
     <a href="testvregadmin.php">
         <img class="images1" src="add2.jpg">
      </a><a class="ak47" href="testvregadmin.php"><p class="para"> Adding a vehicle</p></a><br>
    <a href="testvshow.php">
        <img class="images1" src="tr.png">
        </a><a class="ak47" href="testvshow.php"><p class="para">Show Vehicle</p></a><br>

    </body>
</html>