<!DOCTYPE html>
<html>
<head>
<style> 
#rcorners1 {
    border-radius: 25px;
    background: #73AD21;
    padding: 20px; 
    width: 200px;
    height: 150px;    
}

#rcorners2 {
    border-radius: 25px;
    background: #73AD21;
    padding: 20px; 
    width: 200px;
    height: 150px;  
}

#rcorners3 {
    border-radius: 25px;
    background: #73AD21;
    padding: 20px; 
    width: 200px;
    height: 150px;  
}
</style>
</head>
<body>

<h1>ADMIN PANEL</h1>


<a href="emer.php"><h5 id="rcorners1">SHOW EMERGENCY VEHICLES</h5></a>

<a href="rest.php"><h5 id="rcorners1">TRACK VEHICLES</h5></a>
<a href="unregSHOW.php"><h5 id="rcorners1">UNREGISTERED VEHICLES</h5></a>
</body>
</html>
