<!DOCTYPE html>
<html>
    <head>
    <title>
       vehicles page
    </title>
    <link rel="stylesheet" type="text/css" href="testvregadmin.css">
    
    </head>
    <body>
        <?php include 'headerinclude.php';?>
        
     <a href="vehicleregistration.php">
         <img class="images1" src="1.jpg">
      </a><a class="ak47" href="vehicleregistration.php"><p class="para"> Adding a vehicle</p></a><br>
    <a href="delpage.php">
        <img class="images1" src="2.png">
        </a><a class="ak47" href="delpage.php"><p class="para">Delete Vehicle</p></a><br>
    <a href="showtable1.php">
        <img class="images1" src="3.png">
        </a><a class="ak47" href="showtable1.php"><p class="para">Show Vehicle</p></a><br>

    </body>
</html>