<!DOCTYPE html>
<html>
    <head>
    <title>
       vehicles page
    </title>
    <link rel="stylesheet" type="text/css" href="testvshow.css">
    
    </head>
    <body>
        <?php include 'headerinclude.php';?>
        
     <a href="emer.php">
         <img class="images1" src="1.jpg">
      </a><a class="ak47" href="emer.php"><p class="para"> SHOW EMERGENCY VEHICLES</p></a><br>
    <a href="rest.php">
        <img class="images1" src="5.jpg">
        </a><a class="ak47" href="rest.php"><p class="para">TRACK VEHICLES</p></a><br>
        <a href="unregSHOW.php">
        <img class="images1" src="6.jpg">
        </a><a class="ak47" href="unregSHOW.php"><p class="para">UNREGISTERED VEHICLES</p></a><br>

    </body>
</html>