<html>
<form action="del.php" method="POST">
	<P>ENTER USERNAME : 
		<input type="text" id="user" name="user" />
	</P>
	<p>
		<input type="submit" id="btn" value="delete" />
	</p>
</form>
</html>
