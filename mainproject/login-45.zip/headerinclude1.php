<!DOCTYPE html>
<html>
    <head>
    <title>
       vehicles page
    </title>
    <style>
body {
	line-height: 1.2;
	background-color: rgb(254,250,246);
}

header {
	position: fixed;
	top: 0;
	vertical-align: middle;
	width: 100%;
	background-color: rgb(27,45,94);
	padding: 10px 0 5px 0;
	text-align: center;
	color: rgb(255,255,255);
	text-shadow: 2px 2px 1px rgba(255,255,255,.5);
	font: normal 28px 'League Gothic', Arial, sans-serif;
	letter-spacing: 2px;
}
        table {
    border-collapse: collapse;
    border: 1px solid black;
} 

th,td {
    border: 1px solid ;
    border-color: blueviolet;
}
table {
    table-layout: fixed;
    width: 100%;    
}
</style>
</head>
<body>
	<header>
		SMART TRAFFIC CONTROL SYSTEM
	</header>
</body>
</html>