<html>
    <head>
    
    <title>
    rfid
    </title>
    <link rel="stylesheet" type=text/css href="style1.css">
        </head>
    <body>
    
    <?php include "headerinclude1.php" ?>
<form class="form1" action="refidprocess.php" method="POST">
    
  <P>ENTER USERNAME : 
    <input type="text" id="user" name="user" />
  </P>
  <p>
    <input type="submit" id="btn" value="done" />
  </p>
</form>
        </body>
</html>
